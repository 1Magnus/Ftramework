class Not_found_404_view:

    def __call__(self, request):
        print(request)
        return '404 WHAT', '404 PAGE Not Found'


class Application:

    def __init__(self, routes, fronts):
        self.routes = routes
        self.fronts = fronts

    def __call__(self, environ, start_response):

        path = environ['PATH_INFO']
        # если последний символ отличается от '/' тогда его добавляем
        if not path[-1] == '/':
            path = f'{path}/'
        # согласно пути вибираем вью
        if path in self.routes:
            view = self.routes[path]
        else:
            view = Not_found_404_view()
        request = {}
        # front controller
        for front in self.fronts:
            front(request)
        print(request)
        code, body = view(request)
        start_response(code, [('Content-Type', 'text/html')])
        return [body.encode('utf-8')]
