from framework.jinja import render


class Index_view:

    def __call__(self, request):
        print(request)
        render_base = render('base.html', date=request.get('date'))
        return '200 OK', render_base


class About_view:

    def __call__(self, request):
        render_base = render('base.html', date=request.get('date'))
        return '200 OK', render_base


class Photo_view:

    def __call__(self, request):
        print(request)
        render_base = render('base.html', date=request.get('date'))
        return '200 OK', render_base
