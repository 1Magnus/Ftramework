from views import Index_view, About_view, Photo_view
from datetime import date

routes = {
    '/': Index_view(),
    '/index/': Index_view(),
    '/about/': About_view(),
    '/photo/': Photo_view(),
}


def date_front(request):
    request['date'] = date.today()


def other_front(request):
    request['key'] = 'key'


fronts = [date_front, other_front]
